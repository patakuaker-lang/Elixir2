package com.elixir.tracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    // ===== AJUSTES: si no detecta bien, tocá estos números =====
    // Barra de elixir (para detectar el inicio de la partida), 0.0 = arriba, 1.0 = abajo
    private val stripTop = 0.94f
    private val stripBottom = 0.985f
    private val xFrom = 0.12f
    private val xTo = 0.95f
    private val onThreshold = 0.20f
    private val offThreshold = 0.04f
    // Zona de la pantalla que se considera "lado del rival" (arriba del río)
    private val rivalTop = 0.10f
    private val rivalBottom = 0.45f
    // Zona de la pantalla que se considera "tu lado" (abajo del río)
    private val myTop = 0.55f
    private val myBottom = 0.82f
    // Confianza mínima de la IA para contar una carta
    private val minScore = 0.60f
    // ===========================================================

    private val h = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private var detector: Detector? = null
    private var status = "IA sin cargar"
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var wm: WindowManager? = null
    private var root: View? = null
    private var tv: TextView? = null
    private var tv2: TextView? = null
    private var tv3: TextView? = null
    private var running = false
    private var t = 0.0
    private var el = 5.0
    private var on = 0
    private var off = 0
    private var frac = 0f
    private var lastF = 0L
    private val plays = ArrayList<String>()
    private val lastSeen = HashMap<String, Long>()
    private val suppress = HashMap<String, Long>()
    private var myDeck: Set<String> = emptySet()
    private val mySeen = HashMap<String, Long>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val code = i?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = i?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        startFg()
        try {
            val d = Detector(this)
            detector = d
            status = "IA cargada (${d.names.size} cartas)"
        } catch (e: Throwable) {
            status = "IA no cargó: ${e.message}"
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        proj = mpm.getMediaProjection(code, data)
        proj?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, h)
        startCapture()
        buildOverlay()
        h.post(tick)
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("el", "Elixir", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "el")
            .setContentTitle("Contador de elixir activo")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        val w = dm.widthPixels / 2
        val hh = dm.heightPixels / 2
        val r = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2)
        reader = r
        vd = proj!!.createVirtualDisplay(
            "cap", w, hh, dm.densityDpi / 2,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h
        )
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.elapsedRealtime()
                if (now - lastF >= 300) { lastF = now; analyze(img) }
            } finally { img.close() }
        }, h)
    }

    private fun analyze(img: Image) {
        val p = img.planes[0]
        val buf = p.buffer
        val rs = p.rowStride
        val ps = p.pixelStride
        val w = img.width
        val hh = img.height
        val y0 = (hh * stripTop).toInt()
        val y1 = (hh * stripBottom).toInt()
        val x0 = (w * xFrom).toInt()
        val x1 = (w * xTo).toInt()
        var tot = 0
        var pink = 0
        for (y in y0 until y1) for (x in x0 until x1) {
            val o = y * rs + x * ps
            val r = buf.get(o).toInt() and 255
            val g = buf.get(o + 1).toInt() and 255
            val b = buf.get(o + 2).toInt() and 255
            tot++
            if (r > 170 && b > 150 && g < 120 && r - g > 80 && b - g > 60) pink++
        }
        frac = if (tot > 0) pink.toFloat() / tot else 0f
        if (!running) {
            if (frac >= onThreshold) { if (++on >= 3) startMatch() } else on = 0
        } else {
            if (frac <= offThreshold) { if (++off >= 12) stopMatch() } else off = 0
        }
        val det = detector
        if (running && det != null && !busy.get()) {
            val full = Bitmap.createBitmap(rs / ps, hh, Bitmap.Config.ARGB_8888)
            buf.rewind()
            full.copyPixelsFromBuffer(buf)
            val sc = Bitmap.createScaledBitmap(Bitmap.createBitmap(full, 0, 0, w, hh), det.inputSize, det.inputSize, true)
            busy.set(true)
            exec.execute {
                try {
                    val r = det.detect(sc)
                    h.post { status = "IA ok: ${r.size} objetos"; onDetections(r) }
                } catch (e: Throwable) {
                    h.post { status = "Error IA: ${e.message}" }
                } finally { busy.set(false) }
            }
        }
    }

    private fun onDetections(dets: List<Det>) {
        if (!running) return
        val now = SystemClock.elapsedRealtime()
        for (d in dets) {
            if (d.score < minScore) continue
            val name = Cards.alias[d.name] ?: d.name
            if (d.cy > myTop && d.cy < myBottom) { mySeen[name] = now; continue }
            if (d.cy < rivalTop || d.cy > rivalBottom) continue
            if (name in myDeck) {
                // carta que tambien tengo yo: es del rival solo si no la vi hace poco de mi lado
                if (name in Cards.spells) continue
                if (now - (mySeen[name] ?: -100000L) < 25000) continue
            }
            val c = Cards.cost[name] ?: continue
            if (c == 0) continue
            if ((suppress[name] ?: 0L) > now) { lastSeen[name] = now; continue }
            val gap = now - (lastSeen[name] ?: -100000L)
            lastSeen[name] = now
            if (gap > 4000) registerPlay(name, c, now)
        }
    }

    private fun registerPlay(name: String, c: Int, now: Long) {
        el = maxOf(0.0, el - c)
        plays.add(name)
        Cards.spawns[name]?.forEach { suppress[it] = now + 30000 }
    }

    private fun startMatch() {
        running = true; t = 0.0; el = 5.0; on = 0; off = 0
        plays.clear(); lastSeen.clear(); suppress.clear(); mySeen.clear()
        myDeck = getSharedPreferences("p", 0).getStringSet("deck", emptySet()) ?: emptySet()
    }
    private fun stopMatch() { running = false; on = 0; off = 0 }
    private fun mult() = if (t < 120) 1 else if (t < 240) 2 else 3

    private val tick = object : Runnable {
        override fun run() {
            if (running) { t += 0.1; el = minOf(10.0, el + 0.1 * mult() / 2.8) }
            render()
            h.postDelayed(this, 100)
        }
    }

    private fun render() {
        if (running) {
            val mm = (t / 60).toInt()
            val ss = String.format("%02d", t.toInt() % 60)
            tv?.text = "Rival: ${el.toInt()}   $mm:$ss   x${mult()}"
        } else {
            tv?.text = "Esperando partida… ${(frac * 100).toInt()}% (tocá para iniciar)"
        }
        tv2?.text = when {
            plays.size >= 4 -> "Ciclo: " + plays.takeLast(4).joinToString(" > ")
            plays.isNotEmpty() -> "Jugó: " + plays.joinToString(", ")
            else -> "Sin cartas vistas"
        }
        tv3?.text = status
    }

    private fun buildOverlay() {
        wm = getSystemService(WindowManager::class.java)
        val d = resources.displayMetrics.density
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(12, 8, 12, 8)
        }
        tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f
            setOnClickListener { if (running) stopMatch() else startMatch() }
        }
        tv2 = TextView(this).apply { setTextColor(0xFF9BE08A.toInt()); textSize = 12f }
        tv3 = TextView(this).apply { setTextColor(0xFFAAAAAA.toInt()); textSize = 10f }
        box.addView(tv); box.addView(tv2); box.addView(tv3)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (c in 1..7) {
            row.addView(Button(this).apply {
                text = "$c"; textSize = 12f; minWidth = 0; minimumWidth = 0; setPadding(0, 0, 0, 0)
                setOnClickListener { el = maxOf(0.0, el - c) }
            }, LinearLayout.LayoutParams((38 * d).toInt(), (38 * d).toInt()))
        }
        box.addView(row)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 300 }
        wm?.addView(box, lp)
        root = box
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        exec.shutdownNow()
        try { root?.let { wm?.removeView(it) } } catch (_: Exception) {}
        vd?.release(); reader?.close(); proj?.stop()
        super.onDestroy()
    }
}
