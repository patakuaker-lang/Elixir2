package com.elixir.tracker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        l.addView(TextView(this).apply {
            textSize = 16f
            text = "Contador de elixir para Clash Royale\n\n" +
                "1) Dá el permiso de superposición.\n" +
                "2) (Recomendado) Elegí Mi mazo, así la app distingue tus cartas de las del rival.\n" +
                "3) Tocá Iniciar y aceptá la captura de pantalla.\n" +
                "4) Abrí Clash Royale: arranca solo al empezar la partida y detecta las cartas del rival.\n\n" +
                "En la ventanita podés corregir a mano tocando el costo de una carta."
        })
        fun btn(t: String, f: () -> Unit) {
            l.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        }
        btn("1. Permiso de superposición") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Mi mazo (tus 8 cartas)") { pickDeck() }
        btn("3. Iniciar") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Primero dá el permiso de superposición", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                val m = getSystemService(MediaProjectionManager::class.java)
                startActivityForResult(m.createScreenCaptureIntent(), 42)
            }
        }
        btn("Detener") { stopService(Intent(this, CaptureService::class.java)) }
        setContentView(l)
    }

    private fun pickDeck() {
        val all = try {
            assets.open("clases.txt").bufferedReader().readLines().map { it.trim() }
                .filter { it.isNotEmpty() && !Cards.alias.containsKey(it) && Cards.cost[it] != 0 }.sorted()
        } catch (e: Exception) { emptyList() }
        val prefs = getSharedPreferences("p", 0)
        val sel = (prefs.getStringSet("deck", emptySet()) ?: emptySet()).toMutableSet()
        val items = all.toTypedArray()
        val checked = BooleanArray(items.size) { items[it] in sel }
        AlertDialog.Builder(this)
            .setTitle("Elegí tus 8 cartas")
            .setMultiChoiceItems(items, checked) { _, i, on -> if (on) sel.add(items[i]) else sel.remove(items[i]) }
            .setPositiveButton("Guardar") { _, _ -> prefs.edit().putStringSet("deck", HashSet(sel)).apply() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    @Deprecated("usa API clásica a propósito")
    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) {
        super.onActivityResult(rq, rc, d)
        if (rq == 42 && rc == RESULT_OK && d != null) {
            val i = Intent(this, CaptureService::class.java).putExtra("code", rc).putExtra("data", d)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
