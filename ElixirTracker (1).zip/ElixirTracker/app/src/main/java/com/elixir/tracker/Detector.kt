package com.elixir.tracker

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class Det(val name: String, val score: Float, val cx: Float, val cy: Float)

class Detector(ctx: Context) {
    val names: List<String> = ctx.assets.open("clases.txt").bufferedReader()
        .readLines().map { it.trim() }.filter { it.isNotEmpty() }
    private val interp: Interpreter
    private val nchw: Boolean
    private val chFirst: Boolean
    private val d1: Int
    private val d2: Int
    val inputSize: Int
    private val inBuf: ByteBuffer

    private class B(val c: Int, val s: Float, val x: Float, val y: Float, val w: Float, val h: Float)

    init {
        val bytes = ctx.assets.open("modelo_cartas.tflite").readBytes()
        val mb = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        mb.put(bytes); mb.rewind()
        interp = Interpreter(mb, Interpreter.Options().setNumThreads(4))
        val ish = interp.getInputTensor(0).shape()
        nchw = ish[1] == 3
        inputSize = if (nchw) ish[2] else ish[1]
        val osh = interp.getOutputTensor(0).shape()
        d1 = osh[1]; d2 = osh[2]
        chFirst = d1 < d2
        inBuf = ByteBuffer.allocateDirect(4 * 3 * inputSize * inputSize).order(ByteOrder.nativeOrder())
    }

    fun detect(bmp: Bitmap): List<Det> {
        val n = inputSize
        val px = IntArray(n * n)
        bmp.getPixels(px, 0, n, 0, 0, n, n)
        inBuf.rewind()
        val fb = inBuf.asFloatBuffer()
        if (nchw) {
            for (c in 0..2) {
                val sh = 16 - 8 * c
                for (p in px) fb.put(((p shr sh) and 255) / 255f)
            }
        } else {
            for (p in px) {
                fb.put(((p shr 16) and 255) / 255f)
                fb.put(((p shr 8) and 255) / 255f)
                fb.put((p and 255) / 255f)
            }
        }
        inBuf.rewind()
        val out = Array(1) { Array(d1) { FloatArray(d2) } }
        interp.run(inBuf, out)
        val o = out[0]
        val nAnch = if (chFirst) d2 else d1
        val nCh = if (chFirst) d1 else d2
        fun v(ch: Int, i: Int) = if (chFirst) o[ch][i] else o[i][ch]
        val cand = ArrayList<B>()
        for (i in 0 until nAnch) {
            var best = -1
            var bs = 0f
            for (c in 4 until nCh) {
                val s = v(c, i)
                if (s > bs) { bs = s; best = c - 4 }
            }
            if (bs < 0.5f || best < 0 || best >= names.size) continue
            var cx = v(0, i); var cy = v(1, i); var w = v(2, i); var h = v(3, i)
            if (cx > 1.5f || cy > 1.5f) { cx /= n; cy /= n; w /= n; h /= n }
            cand.add(B(best, bs, cx, cy, w, h))
        }
        cand.sortByDescending { it.s }
        val keep = ArrayList<B>()
        for (b in cand) {
            if (keep.none { it.c == b.c && iou(it, b) > 0.5f }) keep.add(b)
        }
        return keep.map { Det(names[it.c], it.s, it.x, it.y) }
    }

    private fun iou(a: B, b: B): Float {
        val ax1 = a.x - a.w / 2; val ay1 = a.y - a.h / 2; val ax2 = a.x + a.w / 2; val ay2 = a.y + a.h / 2
        val bx1 = b.x - b.w / 2; val by1 = b.y - b.h / 2; val bx2 = b.x + b.w / 2; val by2 = b.y + b.h / 2
        val iw = maxOf(0f, minOf(ax2, bx2) - maxOf(ax1, bx1))
        val ih = maxOf(0f, minOf(ay2, by2) - maxOf(ay1, by1))
        val inter = iw * ih
        val u = a.w * a.h + b.w * b.h - inter
        return if (u <= 0f) 0f else inter / u
    }
}
