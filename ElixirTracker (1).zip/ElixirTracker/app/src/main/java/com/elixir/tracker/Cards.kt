package com.elixir.tracker

object Cards {
    private const val RAW = "Archer Queen:5,Archers:3,Arrows:3,Baby Dragon:4,Balloon:5,Bandit:3,Barbarians:5,Bats:2,Battle Healer:4,Battle Ram:4,Berserker:2,Bomb Tower:4,Bomber:2,Boss Bandit:6,Bowler:5,Cannon:3,Cannon Cart:5,Cursed Hog:0,Dark Prince:4,Dart Goblin:3,Electro Dragon:5,Electro Giant:7,Electro Spirit:1,Electro Wizard:4,Elite Barbarians:6,Elixir Collector:6,Elixir Golem:3,Executioner:5,Fire Spirit:1,Fireball:4,Firecracker:3,Fisherman:3,Flying Machine:4,Furnace:4,Giant:5,Giant Skeleton:6,Giant Snowball:2,Goblin Barrel:3,Goblin Cage:4,Goblin Demolisher:4,Goblin Drill:4,Goblin Giant:6,Goblin Hut:4,Goblin Machine:5,Goblins:2,Goblinstein:5,Golden Knight:4,Golem:8,Graveyard:5,Guards:3,Heal Spirit:1,Hog Rider:4,Hunter:4,Ice Golem:2,Ice Spirit:1,Ice Wizard:3,Inferno Dragon:4,Inferno Tower:5,Knight:3,Lava Hound:7,Little Prince:3,Lumberjack:4,Magic Archer:4,Mega Knight:7,Mega Minion:3,Mighty Miner:4,Miner:3,Mini P.E.K.K.A:4,Minions:3,Monk:5,Mortar:4,Mother Witch:4,Musketeer:4,Night Witch:4,P.E.K.K.A:7,Phoenix:4,Poison:4,Prince:5,Princess:3,Rage:2,Ram Rider:5,Rascals:5,Rocket:6,Royal Ghost:3,Royal Giant:6,Royal Hog:5,Royal Hogs:5,Royal Recruits:7,Skeleton:0,Skeleton Barrel:3,Skeleton Dragons:4,Skeleton King:4,Skeletons:1,Sparky:6,Spear Goblins:2,Spirit Empress:3,Suspicious Bush:2,Tesla:4,The Log:2,Tombstone:3,Tornado:3,Valkyrie:4,Wall Breakers:2,Witch:5,Wizard:5,X-Bow:6,Zappies:4"

    // costo de elixir por carta (0 = unidad que solo aparece como invocada, se ignora)
    val cost: Map<String, Int> = RAW.split(",").associate {
        val i = it.lastIndexOf(':')
        it.substring(0, i) to it.substring(i + 1).toInt()
    }

    // hechizos: no se pueden distinguir los tuyos de los del rival, si estan en tu mazo se ignoran
    val spells = setOf("Arrows", "Fireball", "Rocket", "Poison", "Rage", "The Log", "Tornado",
        "Giant Snowball", "Goblin Barrel", "Graveyard")

    // nombres distintos de la misma carta
    val alias = mapOf("Royal Hog" to "Royal Hogs")

    // cartas que invocan unidades: esas unidades no cuentan como jugada nueva
    val spawns = mapOf(
        "Night Witch" to listOf("Bats"),
        "Tombstone" to listOf("Skeleton", "Skeletons"),
        "Skeleton King" to listOf("Skeleton", "Skeletons"),
        "Graveyard" to listOf("Skeleton", "Skeletons"),
        "Witch" to listOf("Skeleton", "Skeletons"),
        "Skeleton Barrel" to listOf("Skeletons"),
        "Goblin Hut" to listOf("Spear Goblins"),
        "Goblin Giant" to listOf("Spear Goblins"),
        "Furnace" to listOf("Fire Spirit"),
        "Goblin Drill" to listOf("Goblins"),
        "Mother Witch" to listOf("Cursed Hog")
    )
}
